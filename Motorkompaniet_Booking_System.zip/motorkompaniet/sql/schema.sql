-- ============================================================
-- MOTORKOMPANIET — Booking System Database Schema
-- Run this in Supabase: Dashboard → SQL Editor → New Query
-- ============================================================

-- Bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at    TIMESTAMPTZ DEFAULT now(),

  -- Customer info
  name          TEXT NOT NULL,
  phone         TEXT NOT NULL,
  email         TEXT NOT NULL,

  -- Car info
  reg_number    TEXT NOT NULL,       -- Swedish reg e.g. ABC123
  car_make      TEXT NOT NULL,       -- e.g. Volvo
  car_model     TEXT NOT NULL,       -- e.g. V70
  car_year      INTEGER,             -- e.g. 2018

  -- Booking details
  service_type  TEXT NOT NULL,       -- Bilservice, AC-service etc
  preferred_date DATE NOT NULL,
  preferred_time TEXT NOT NULL,      -- e.g. 08:00, 10:00
  message       TEXT DEFAULT '',     -- Optional notes from customer

  -- Status management
  status        TEXT DEFAULT 'pending'
                CHECK (status IN ('pending','confirmed','completed','cancelled')),

  confirmed_at  TIMESTAMPTZ,
  notes         TEXT DEFAULT ''      -- Internal notes from workshop
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_bookings_status   ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_date     ON bookings(preferred_date);
CREATE INDEX IF NOT EXISTS idx_bookings_created  ON bookings(created_at DESC);

-- Row Level Security — only your backend can read/write
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Allow API (service role) full access
CREATE POLICY "service_role_all" ON bookings
  FOR ALL USING (true);

-- ============================================================
-- TEST DATA — Optional, delete when going live
-- ============================================================
INSERT INTO bookings (name, phone, email, reg_number, car_make, car_model, car_year, service_type, preferred_date, preferred_time, message)
VALUES
  ('Anna Lindqvist', '0701234567', 'anna@example.com', 'ABC123', 'Volvo', 'V70', 2018, 'Bilservice', CURRENT_DATE + 3, '09:00', 'Byt även vindrutetorkare tack'),
  ('Erik Svensson',  '0709876543', 'erik@example.com', 'XYZ789', 'Saab',  '9-5', 2012, 'AC-service', CURRENT_DATE + 5, '11:00', ''),
  ('Maria Karlsson', '0731122334', 'maria@example.com','DEF456', 'BMW',   '3-serie', 2020, 'Däckbyte', CURRENT_DATE + 7, '13:00', 'Vinterhjul i däckhotellet');
